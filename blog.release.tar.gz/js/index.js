document.querySelector(".nav-btn").addEventListener("click",function(){
	document.querySelector(".nav").classList.toggle("show")
	this.classList.toggle("active")
})